import mapel.elections as mapel
import itertools
from scipy.stats import stats
import matplotlib.pyplot as plt

sizes = [4,6,8,10]


if __name__ == "__main__":

    instance_type = 'ordinal'
    distance_id = 'voter_subelection'

    for size in sizes:
        experiment_id = f'preflib_{size}_borda'

        experiment = mapel.prepare_experiment(experiment_id=experiment_id,
                                              instance_type=instance_type,
                                              distance_id=distance_id)

        experiment.prepare_elections()
        experiment.compute_distances(distance_id=distance_id)

        experiment.print_matrix(scale=2., saveas=f'matrix_sub_preflib_{size}',
                                dpi=200, ms=8, vmax=75)


