import mapel
import time
import os
import csv
import sys

if __name__ == "__main__":

    target = str(sys.argv[1])
    SIZE = int(sys.argv[2])

    num_voters = 50
    num_threads = 1

    values = []

    my_dict = {'ic': ['impartial_culture', {}],
               'half': ['norm_mallows', {'norm-phi': 0.5}],
               'wal': ['walsh', {}],
               'con': ['conitzer', {}],
               'int': ['1d_interval', {}],
               'id':  ['real_identity', {}]}

    x_values = [3,4,5,6,7,8,9,10]

    for num_candidates in x_values:

        total_time = 0
        for i in range(SIZE):
            experiment = mapel.prepare_experiment()
            experiment.set_default_num_candidates(num_candidates)
            experiment.set_default_num_voters(num_voters)
            experiment.add_family(election_model=my_dict[target][0], size=2,
                                  params=my_dict[target][1])
            start = time.time()
            experiment.compute_distances(distance_name='0-voter_subelection',
                                         num_threads=num_threads)
            stop = time.time()
            total_time += stop - start
        values.append(total_time/float(SIZE))

        name = target + '_n'
        path = os.path.join(os.getcwd(), 'fix_n', name)

        with open(path, 'w', newline='') as csv_file:
            writer = csv.writer(csv_file, delimiter=',')
            writer.writerow(["id", "value"])
            for i, v in enumerate(values):
                writer.writerow([i, v])






